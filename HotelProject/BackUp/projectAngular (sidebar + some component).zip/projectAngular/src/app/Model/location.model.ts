export class LocationModel {

    id!: number;
    name!: string;
    image!: string;

}