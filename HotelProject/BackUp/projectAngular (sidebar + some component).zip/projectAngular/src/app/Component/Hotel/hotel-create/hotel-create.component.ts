import { Component } from '@angular/core';

@Component({
  selector: 'app-hotel-create',
  templateUrl: './hotel-create.component.html',
  styleUrl: './hotel-create.component.css'
})
export class HotelCreateComponent {

}
