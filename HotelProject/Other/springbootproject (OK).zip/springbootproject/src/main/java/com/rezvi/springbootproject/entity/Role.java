package com.rezvi.springbootproject.entity;

public enum Role {
    ADMIN, USER, HOTEL
}
