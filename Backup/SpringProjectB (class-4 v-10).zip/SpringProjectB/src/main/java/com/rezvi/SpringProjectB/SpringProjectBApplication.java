package com.rezvi.SpringProjectB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectBApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectBApplication.class, args);
	}

}
