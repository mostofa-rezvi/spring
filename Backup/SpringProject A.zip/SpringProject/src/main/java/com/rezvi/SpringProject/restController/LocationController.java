package com.rezvi.SpringProject.restController;

public class LocationController {
}
