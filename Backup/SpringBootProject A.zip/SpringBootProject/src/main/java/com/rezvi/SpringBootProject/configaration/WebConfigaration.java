package com.rezvi.SpringBootProject.configaration;

public class WebConfigaration {
}
