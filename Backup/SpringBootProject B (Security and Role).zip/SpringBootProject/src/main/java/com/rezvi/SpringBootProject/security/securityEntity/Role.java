package com.rezvi.SpringBootProject.security.securityEntity;

public enum Role {

    ADMIN, USER, DOCTOR, NURSE, RECEPTIONIST;
}
