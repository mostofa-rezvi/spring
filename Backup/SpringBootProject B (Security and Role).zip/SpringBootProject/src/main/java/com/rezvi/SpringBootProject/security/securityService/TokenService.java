package com.rezvi.SpringBootProject.security.securityService;

import org.springframework.stereotype.Service;

@Service
public class TokenService {

}
