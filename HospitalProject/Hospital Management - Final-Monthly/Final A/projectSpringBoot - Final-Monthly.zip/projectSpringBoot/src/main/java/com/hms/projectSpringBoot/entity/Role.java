package com.hms.projectSpringBoot.entity;

public enum Role {

    ADMIN,
    PATIENT,
    DOCTOR,
    NURSE,
    RECEPTIONIST,
    PHARMACIST

}
