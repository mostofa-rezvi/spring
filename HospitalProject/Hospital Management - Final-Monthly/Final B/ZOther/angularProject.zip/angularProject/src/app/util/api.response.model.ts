export class ApiResponse {
  message?: string
  data?: any
  successful?: boolean
}
