import { Component } from '@angular/core';

@Component({
  selector: 'app-updatereportdoc',
  templateUrl: './updatereportdoc.component.html',
  styleUrl: './updatereportdoc.component.css'
})
export class UpdatereportdocComponent {

}
