import { Component } from '@angular/core';

@Component({
  selector: 'app-doctorpnt',
  templateUrl: './doctorpnt.component.html',
  styleUrl: './doctorpnt.component.css'
})
export class DoctorpntComponent {

}
