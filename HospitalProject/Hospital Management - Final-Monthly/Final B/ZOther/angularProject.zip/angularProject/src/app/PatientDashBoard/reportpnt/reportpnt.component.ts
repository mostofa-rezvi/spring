import { Component } from '@angular/core';

@Component({
  selector: 'app-reportpnt',
  templateUrl: './reportpnt.component.html',
  styleUrl: './reportpnt.component.css'
})
export class ReportpntComponent {

}
