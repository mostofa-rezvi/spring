import { Component } from '@angular/core';

@Component({
  selector: 'app-appointmentpnt',
  templateUrl: './appointmentpnt.component.html',
  styleUrl: './appointmentpnt.component.css'
})
export class AppointmentpntComponent {

}
