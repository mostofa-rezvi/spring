import { Component } from '@angular/core';

@Component({
  selector: 'app-adminpayroll',
  templateUrl: './adminpayroll.component.html',
  styleUrl: './adminpayroll.component.css'
})
export class AdminpayrollComponent {

}
