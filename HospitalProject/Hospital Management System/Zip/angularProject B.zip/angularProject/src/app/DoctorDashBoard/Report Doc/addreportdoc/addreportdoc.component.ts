import { Component } from '@angular/core';

@Component({
  selector: 'app-addreportdoc',
  templateUrl: './addreportdoc.component.html',
  styleUrl: './addreportdoc.component.css'
})
export class AddreportdocComponent {

}
