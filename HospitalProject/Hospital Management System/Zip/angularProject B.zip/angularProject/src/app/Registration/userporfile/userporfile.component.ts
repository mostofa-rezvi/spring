import { Component } from '@angular/core';

@Component({
  selector: 'app-userporfile',
  templateUrl: './userporfile.component.html',
  styleUrl: './userporfile.component.css'
})
export class UserporfileComponent {

}
