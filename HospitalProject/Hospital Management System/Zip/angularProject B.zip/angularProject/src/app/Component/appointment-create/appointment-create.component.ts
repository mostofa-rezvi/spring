import { Component, OnInit } from '@angular/core';
import { AppointmentModel } from '../model/appointment.model';
import { AppointmentService } from '../service/appointment.service';

@Component({
  selector: 'app-appointment-create',
  templateUrl: './appointment-create.component.html',
  styleUrl: './appointment-create.component.css'
})
export class AppointmentCreateComponent implements OnInit {

  appointment: AppointmentModel = new AppointmentModel();

  constructor(
    private appointmentService: AppointmentService
  ) { }

  ngOnInit(): void { 

  }

  createAppointment(): void {
    this.appointmentService.createAppointment(this.appointment)
    .subscribe({
      next: (res: any) => {
        console.log('Appointment created successfully:', res);
        alert('Appointment successfully created!');
      },
      error: (error: any) => {
        console.error('Error creating appointment:', error);
        alert('Error creating appointment.');
      }
    });
  }

}