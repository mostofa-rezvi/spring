export class ReceptionistProfileModel {
    name!: string;
    phone!: string;
    email!: string;
    address!: string;
    gender!: string;
    avatar!: string;
    employeeId!: string;
    position!: string;
    department!: string;
    workHours!: string;
}
