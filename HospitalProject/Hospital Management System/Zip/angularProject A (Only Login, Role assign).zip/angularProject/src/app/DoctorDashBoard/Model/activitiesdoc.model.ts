export class ActivitiesDocModel {
  id!: string;
  doctorId!: string;
  activityType!: string;
  description!: string;
  activityDate!: string;
  status!: string;
  date!: string;
}
