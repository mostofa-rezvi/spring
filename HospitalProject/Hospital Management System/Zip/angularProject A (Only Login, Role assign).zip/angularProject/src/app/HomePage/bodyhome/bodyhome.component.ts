import { Component } from '@angular/core';

@Component({
  selector: 'app-bodyhome',
  templateUrl: './bodyhome.component.html',
  styleUrl: './bodyhome.component.css'
})
export class BodyhomeComponent {

}
