import { Component } from '@angular/core';

@Component({
  selector: 'app-settingspnt',
  templateUrl: './settingspnt.component.html',
  styleUrl: './settingspnt.component.css'
})
export class SettingspntComponent {

}
