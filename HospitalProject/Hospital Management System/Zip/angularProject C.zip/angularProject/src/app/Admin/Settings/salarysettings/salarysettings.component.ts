import { Component } from '@angular/core';

@Component({
  selector: 'app-salarysettings',
  templateUrl: './salarysettings.component.html',
  styleUrl: './salarysettings.component.css'
})
export class SalarysettingsComponent {

}
