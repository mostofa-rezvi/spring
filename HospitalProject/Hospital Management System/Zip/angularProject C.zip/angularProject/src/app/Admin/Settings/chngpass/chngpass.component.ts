import { Component } from '@angular/core';

@Component({
  selector: 'app-chngpass',
  templateUrl: './chngpass.component.html',
  styleUrl: './chngpass.component.css'
})
export class ChngpassComponent {

}
