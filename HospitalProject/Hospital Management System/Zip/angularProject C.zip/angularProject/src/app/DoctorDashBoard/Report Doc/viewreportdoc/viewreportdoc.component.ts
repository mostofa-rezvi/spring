import { Component } from '@angular/core';

@Component({
  selector: 'app-viewreportdoc',
  templateUrl: './viewreportdoc.component.html',
  styleUrl: './viewreportdoc.component.css'
})
export class ViewreportdocComponent {

}
