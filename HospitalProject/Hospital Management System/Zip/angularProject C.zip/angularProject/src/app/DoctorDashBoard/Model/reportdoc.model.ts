export class ReportDocModel {
  id!: number;
  doctorId!: number;
  reportDate!: string;
  patientName!: string;
  reportType!: string;
  description!: string;
  results!: string;
  status!: string;
}
