import { Component } from '@angular/core';

@Component({
  selector: 'app-paymentpnt',
  templateUrl: './paymentpnt.component.html',
  styleUrl: './paymentpnt.component.css'
})
export class PaymentpntComponent {

}
