import { Component } from '@angular/core';

@Component({
  selector: 'app-footerhome',
  templateUrl: './footerhome.component.html',
  styleUrl: './footerhome.component.css'
})
export class FooterhomeComponent {

}
