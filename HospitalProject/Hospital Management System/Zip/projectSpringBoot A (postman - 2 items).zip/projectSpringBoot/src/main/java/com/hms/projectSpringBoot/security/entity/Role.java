package com.hms.projectSpringBoot.security.entity;

public enum Role {

    ADMIN,
    PATIENT,
    DOCTOR,
    NURSE,
    RECEPTIONIST,
    PHARMACIST

}
