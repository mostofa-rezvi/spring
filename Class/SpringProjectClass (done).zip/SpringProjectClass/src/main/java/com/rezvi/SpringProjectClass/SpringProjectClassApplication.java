package com.rezvi.SpringProjectClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectClassApplication.class, args);
	}

}
