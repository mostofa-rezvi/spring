package com.rezvi.SpringProjectClass.restController;

public class LocationController {
}
