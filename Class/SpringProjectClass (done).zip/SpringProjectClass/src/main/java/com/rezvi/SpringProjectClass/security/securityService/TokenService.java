package com.rezvi.SpringProjectClass.security.securityService;

import org.springframework.stereotype.Service;

@Service
public class TokenService {

}
