package com.rezvi.SpringProjectClass.security.securityEntity;

public enum Role {

    ADMIN, USER, HOTEL;
}
