package com.rezvi.SpringProjectClass.configaration;

public class WebConfigaration {
}
