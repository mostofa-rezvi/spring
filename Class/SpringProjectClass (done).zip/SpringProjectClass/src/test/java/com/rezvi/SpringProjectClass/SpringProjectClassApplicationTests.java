package com.rezvi.SpringProjectClass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectClassApplicationTests {

	@Test
	void contextLoads() {
	}

}
