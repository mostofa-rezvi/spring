package com.rezvi.SpringProjectB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectBApplicationTests {

	@Test
	void contextLoads() {
	}

}
